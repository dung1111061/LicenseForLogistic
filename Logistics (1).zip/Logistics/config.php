<?php
define("HOST_DB", 'localhost');
define("USER_DB", 'root');
define("PASS_DB", '');
define("DB", 'dev_sslog');

define ('ROOT', dirname(__FILE__));
define('BASE_URL', 'http://localhost/Project/Logistics');
define('UPLOAD_IMG', ROOT .'/images/book');

error_reporting(E_ALL);

