<form action="index.php?controller=Admin&action=process_UpdateChungTu&id=<?=$chungTu->id?>" method="post">	
		<?php 	
		include "ChungTu.php"
		?>
</form>